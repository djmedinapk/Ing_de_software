﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Elogin
/// </summary>
public class Elogin
{
    
	public Elogin()
	{

		// TODO: Agregar aquí la lógica del constructor
		//
	}
    private string password;
    private string username;

    public string Password { get => password; set => password = value; }
    public string Username { get => username; set => username = value; }
}