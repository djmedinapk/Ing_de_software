--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.4
-- Dumped by pg_dump version 9.6.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.empresa DROP CONSTRAINT fk_user;
ALTER TABLE ONLY public.estudios DROP CONSTRAINT fk_user;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT pk_id_rol;
ALTER TABLE ONLY public.productos DROP CONSTRAINT pk_id_producto;
ALTER TABLE ONLY public.estudios DROP CONSTRAINT pk_estudios;
ALTER TABLE ONLY public.empresa DROP CONSTRAINT pk_empresa;
ALTER TABLE public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id_rol DROP DEFAULT;
ALTER TABLE public.productos ALTER COLUMN id_producto DROP DEFAULT;
ALTER TABLE public.estudios ALTER COLUMN id_estudios DROP DEFAULT;
ALTER TABLE public.empresa ALTER COLUMN id_empresa DROP DEFAULT;
DROP SEQUENCE public.user_id_seq;
DROP SEQUENCE public.roles_id_rol_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.productos_id_producto_seq;
DROP SEQUENCE public.estudios_id_estudios_seq;
DROP SEQUENCE public.empresa_id_empresa_seq;
DROP FUNCTION public.f_obtener_usuario(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying);
DROP FUNCTION public.f_obtener_usuario();
DROP TABLE public."user";
DROP FUNCTION public.f_obtener_productos(_condicion1 character varying, _condicion2 integer);
DROP TABLE public.productos;
DROP FUNCTION public.f_obtener_estudios(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying);
DROP TABLE public.estudios;
DROP FUNCTION public.f_obtener_empresa(_condicion1 character varying);
DROP TABLE public.empresa;
DROP FUNCTION public.f_insertar_usuario(_nombre character varying, _username character varying, _clave character varying, _telefono character varying, _correo character varying, _profesion character varying);
DROP FUNCTION public.f_insertar_estudios(_username character varying, _nivel_educativo character varying, _nombre_instituto character varying, _ciudad_instituto character varying, _ano_fin character varying);
DROP FUNCTION public.f_insertar_empresa(_username character varying, _nombre_empresa character varying, _cargo_empresa character varying, _tiempo_empresa character varying, _jefe_empresa character varying);
DROP FUNCTION public.f_consultar_login(_password character varying, _username character varying);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: user; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "user" IS 'Base de datos del ejemplo 2';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: f_consultar_login(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_consultar_login(_password character varying, _username character varying) RETURNS SETOF integer
    LANGUAGE plpgsql
    AS $$

	BEGIN
    	RETURN QUERY
    	SELECT rol from public."user" where clave = _Password AND username = _Username;
  END

$$;


ALTER FUNCTION public.f_consultar_login(_password character varying, _username character varying) OWNER TO postgres;

--
-- Name: f_insertar_empresa(character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_insertar_empresa(_username character varying, _nombre_empresa character varying, _cargo_empresa character varying, _tiempo_empresa character varying, _jefe_empresa character varying) RETURNS SETOF void
    LANGUAGE plpgsql
    AS $$
	BEGIN
    	INSERT INTO public."empresa" (
		id_usuario,
    nombre_empresa,
    cargo_empresa,
    tiempo_empresa,
    jefe_empresa
	)
    VALUES(
        (SELECT id from public."user" where public."user"."username" = _Username),
      	_Nombre_empresa,
      	_Cargo_empresa,
      	_Tiempo_empresa,
      	_Jefe_empresa
    );
  
  END
$$;


ALTER FUNCTION public.f_insertar_empresa(_username character varying, _nombre_empresa character varying, _cargo_empresa character varying, _tiempo_empresa character varying, _jefe_empresa character varying) OWNER TO postgres;

--
-- Name: f_insertar_estudios(character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_insertar_estudios(_username character varying, _nivel_educativo character varying, _nombre_instituto character varying, _ciudad_instituto character varying, _ano_fin character varying) RETURNS SETOF void
    LANGUAGE plpgsql
    AS $$	BEGIN
    	INSERT INTO public."estudios" (
		id_user,
    nivel_estudio,
    nombre_instituto,
    ciudad_instituto,
    ano_fin
	)
    VALUES(
        (SELECT id from public."user" where public."user"."username" = _Username),
      	_Nivel_educativo,
      	_Nombre_instituto,
      	_Ciudad_instituto,
      	_Ano_fin
    );
  
  END
$$;


ALTER FUNCTION public.f_insertar_estudios(_username character varying, _nivel_educativo character varying, _nombre_instituto character varying, _ciudad_instituto character varying, _ano_fin character varying) OWNER TO postgres;

--
-- Name: f_insertar_usuario(character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_insertar_usuario(_nombre character varying, _username character varying, _clave character varying, _telefono character varying, _correo character varying, _profesion character varying) RETURNS SETOF void
    LANGUAGE plpgsql
    AS $$
	BEGIN
    	INSERT INTO public."user"
        (
        	nombre,
            username,
            clave,
            telefono,
            correo,
            profesion
         )
         VALUES
         (
         	_Nombre,
            _Username,
            _CLave,
            _Telefono,
            _Correo,
            _Profesion
         );
    END
$$;


ALTER FUNCTION public.f_insertar_usuario(_nombre character varying, _username character varying, _clave character varying, _telefono character varying, _correo character varying, _profesion character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa (
    id_empresa integer NOT NULL,
    id_usuario integer NOT NULL,
    nombre_empresa character varying,
    cargo_empresa character varying,
    tiempo_empresa character varying,
    jefe_empresa character varying
);


ALTER TABLE empresa OWNER TO postgres;

--
-- Name: TABLE empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE empresa IS 'Tabla que almacena información de empresas y experiencia laboral de un usuario';


--
-- Name: f_obtener_empresa(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_obtener_empresa(_condicion1 character varying) RETURNS SETOF empresa
    LANGUAGE plpgsql
    AS $$

	BEGIN
		IF _condicion1 = 'ninguno' THEN 
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."empresa" ;
        	END;
        ELSE
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."empresa"  where nombre_empresa = _condicion1;
        	END;   
        END IF;
	END;

$$;


ALTER FUNCTION public.f_obtener_empresa(_condicion1 character varying) OWNER TO postgres;

--
-- Name: estudios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE estudios (
    id_estudios integer NOT NULL,
    id_user integer NOT NULL,
    nivel_estudio character varying NOT NULL,
    nombre_instituto character varying,
    ciudad_instituto character varying,
    ano_fin character varying
);


ALTER TABLE estudios OWNER TO postgres;

--
-- Name: TABLE estudios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE estudios IS 'Tabla que contiene los estudios de un usuario';


--
-- Name: f_obtener_estudios(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_obtener_estudios(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying) RETURNS SETOF estudios
    LANGUAGE plpgsql
    AS $$

	BEGIN
		IF _condicion1 = 'ninguno' AND _condicion2 = 'ninguno' AND _condicion3 = 'ninguno'  THEN 
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."estudios";
        	END;
        ELSE IF _condicion1 = 'ninguno' AND _condicion2 = 'ninguno' AND _condicion3 != 'ninguno' THEN
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."estudios" where ano_fin = _condicion3;
        	END;
        ELSE IF _condicion1 = 'ninguno' AND _condicion2 !='ninguno' AND _condicion3 = 'ninguno'THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where nombre_instituto = _condicion2;
                END;
        ELSE IF _condicion1 = 'ninguno' AND _condicion2 != 'ninguno' AND _condicion3 != 'ninguno' THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where nombre_instituto = _condicion2 AND ano_fin = _condicion3;
                END;
        ELSE IF _condicion1 != 'ninguno' AND _condicion2 = 'ninguno' AND _condicion3 = 'ninguno' THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where  nivel_estudio = _condicion1;
                END;
        ELSE IF _condicion1 != 'ninguno' AND _condicion2 = 'ninguno' AND _condicion3 != 'ninguno' THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where nivel_estudio = _condicion1 AND ano_fin = _condicion3;
                END;
        ELSE IF _condicion1 != 'ninguno' AND _condicion2 != 'ninguno' AND _condicion3 = 'ninguno' THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where nombre_instituto = _condicion2 AND  nivel_estudio = _condicion1 ;
                END;
        ELSE IF _condicion1 != 'ninguno' AND _condicion2 != 'ninguno' AND _condicion3 != 'ninguno' THEN
            BEGIN
                	RETURN QUERY
                	SELECT * FROM public."estudios" where nombre_instituto = _condicion2 AND  nivel_estudio = _condicion1 AND ano_fin = _condicion3; 
                END;                
        
        
        
        END IF;
        END IF;
        END IF;
        END IF;
        END IF;
        END IF;
        END IF;
        END IF;
        
	END;

$$;


ALTER FUNCTION public.f_obtener_estudios(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying) OWNER TO postgres;

--
-- Name: productos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE productos (
    id_producto integer NOT NULL,
    nombre character varying,
    descripcion character varying,
    precio integer
);


ALTER TABLE productos OWNER TO postgres;

--
-- Name: TABLE productos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE productos IS 'Tabla que contiene informacion sobre productos';


--
-- Name: f_obtener_productos(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_obtener_productos(_condicion1 character varying, _condicion2 integer) RETURNS SETOF productos
    LANGUAGE plpgsql
    AS $$

	BEGIN
		IF _condicion1 = 'ninguno' AND _condicion2 = 0  THEN 
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."productos";
        	END;
        ELSE IF _condicion1 != 'ninguno' AND _condicion2 = 0 THEN
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."productos" where nombre = _condicion1;
        	END;
            ELSE IF _condicion2 != 0 AND _condicion1 ='ninguno' THEN
            	BEGIN
                	RETURN QUERY
                	SELECT * FROM public."productos" where precio <= _condicion2;
                END;
                ELSE IF _condicion1 != 'ninguno' AND _condicion2 != 0 THEN
                BEGIN
                	RETURN QUERY
                	SELECT * FROM public."productos" where nombre = _condicion1 AND precio <= _condicion2;
                END;
        		END IF;
                END IF;
        	END IF;
         END IF;
	END;

$$;


ALTER FUNCTION public.f_obtener_productos(_condicion1 character varying, _condicion2 integer) OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "user" (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    username character varying(100),
    clave character varying,
    telefono character varying,
    correo character varying,
    profesion character varying,
    rol integer DEFAULT 1
);


ALTER TABLE "user" OWNER TO postgres;

--
-- Name: TABLE "user"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "user" IS 'Tabla que almacena los usuarios';


--
-- Name: f_obtener_usuario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_obtener_usuario() RETURNS SETOF "user"
    LANGUAGE plpgsql
    AS $$

	BEGIN
		RETURN QUERY
        SELECT * FROM public."user";
	END;

$$;


ALTER FUNCTION public.f_obtener_usuario() OWNER TO postgres;

--
-- Name: f_obtener_usuario(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION f_obtener_usuario(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying) RETURNS SETOF "user"
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF _condicion1 = 'ninguno' AND _condicion2 = 'ninguno' AND _condicion3 = 'ninguno' THEN 
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."user";
        	END;
        ELSE IF _condicion1 != 'ninguno' THEN
        	BEGIN
        		RETURN QUERY
                SELECT * FROM public."user" where nombre = _condicion1;
        	END;   
        END IF;
        END IF;
	END;
$$;


ALTER FUNCTION public.f_obtener_usuario(_condicion1 character varying, _condicion2 character varying, _condicion3 character varying) OWNER TO postgres;

--
-- Name: empresa_id_empresa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_id_empresa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_id_empresa_seq OWNER TO postgres;

--
-- Name: empresa_id_empresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_id_empresa_seq OWNED BY empresa.id_empresa;


--
-- Name: estudios_id_estudios_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE estudios_id_estudios_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE estudios_id_estudios_seq OWNER TO postgres;

--
-- Name: estudios_id_estudios_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE estudios_id_estudios_seq OWNED BY estudios.id_estudios;


--
-- Name: productos_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE productos_id_producto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE productos_id_producto_seq OWNER TO postgres;

--
-- Name: productos_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE productos_id_producto_seq OWNED BY productos.id_producto;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE roles (
    id_rol integer NOT NULL,
    nombre character varying,
    descripcion character varying
);


ALTER TABLE roles OWNER TO postgres;

--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE roles IS 'tabla que almacena los roles';


--
-- Name: roles_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE roles_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE roles_id_rol_seq OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE roles_id_rol_seq OWNED BY roles.id_rol;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_id_seq OWNED BY "user".id;


--
-- Name: empresa id_empresa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa ALTER COLUMN id_empresa SET DEFAULT nextval('empresa_id_empresa_seq'::regclass);


--
-- Name: estudios id_estudios; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY estudios ALTER COLUMN id_estudios SET DEFAULT nextval('estudios_id_estudios_seq'::regclass);


--
-- Name: productos id_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY productos ALTER COLUMN id_producto SET DEFAULT nextval('productos_id_producto_seq'::regclass);


--
-- Name: roles id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY roles ALTER COLUMN id_rol SET DEFAULT nextval('roles_id_rol_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user" ALTER COLUMN id SET DEFAULT nextval('user_id_seq'::regclass);


--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa (id_empresa, id_usuario, nombre_empresa, cargo_empresa, tiempo_empresa, jefe_empresa) FROM stdin;
\.
COPY empresa (id_empresa, id_usuario, nombre_empresa, cargo_empresa, tiempo_empresa, jefe_empresa) FROM '$$PATH$$/2179.dat';

--
-- Name: empresa_id_empresa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_id_empresa_seq', 13, true);


--
-- Data for Name: estudios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY estudios (id_estudios, id_user, nivel_estudio, nombre_instituto, ciudad_instituto, ano_fin) FROM stdin;
\.
COPY estudios (id_estudios, id_user, nivel_estudio, nombre_instituto, ciudad_instituto, ano_fin) FROM '$$PATH$$/2177.dat';

--
-- Name: estudios_id_estudios_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('estudios_id_estudios_seq', 17, true);


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY productos (id_producto, nombre, descripcion, precio) FROM stdin;
\.
COPY productos (id_producto, nombre, descripcion, precio) FROM '$$PATH$$/2182.dat';

--
-- Name: productos_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('productos_id_producto_seq', 9, true);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY roles (id_rol, nombre, descripcion) FROM stdin;
\.
COPY roles (id_rol, nombre, descripcion) FROM '$$PATH$$/2181.dat';

--
-- Name: roles_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('roles_id_rol_seq', 2, true);


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "user" (id, nombre, username, clave, telefono, correo, profesion, rol) FROM stdin;
\.
COPY "user" (id, nombre, username, clave, telefono, correo, profesion, rol) FROM '$$PATH$$/2175.dat';

--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_id_seq', 14, true);


--
-- Name: empresa pk_empresa; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa
    ADD CONSTRAINT pk_empresa PRIMARY KEY (id_empresa);


--
-- Name: estudios pk_estudios; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY estudios
    ADD CONSTRAINT pk_estudios PRIMARY KEY (id_estudios);


--
-- Name: productos pk_id_producto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY productos
    ADD CONSTRAINT pk_id_producto PRIMARY KEY (id_producto);


--
-- Name: roles pk_id_rol; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT pk_id_rol PRIMARY KEY (id_rol);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: estudios fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY estudios
    ADD CONSTRAINT fk_user FOREIGN KEY (id_user) REFERENCES "user"(id);


--
-- Name: empresa fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa
    ADD CONSTRAINT fk_user FOREIGN KEY (id_usuario) REFERENCES "user"(id);


--
-- PostgreSQL database dump complete
--

